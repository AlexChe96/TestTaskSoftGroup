$(document).ready(function() {
		$("#submit").click(function() {
			if(verificateInput()) {
				submitData();
				$("#notification").html("Successfully inserted");
				document.getElementById("notification").className = "successful";
			} else {
				$("#notification").html("Wrong input values");
				document.getElementById("notification").className = "error";	
			}
		});
		setMaxDateToToday();
	});
	
	function verificateInput() {
		var verification = true;
		if (!verificateTextField($("#name").val())) {
			verification = false;
			$("#name").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#name").removeAttr('style');
		}
		if (!verificateTextField($("#surname").val())) {
			verification = false
			$("#surname").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#surname").removeAttr('style');
		}
		if (!verificateBirthDate()) {
			verification = false;
			$("#date_of_birth").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#date_of_birth").removeAttr('style');
		}
		if (!verificatePhoneNumber()) {
			verification = false;
			$("#phone_number").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#phone_number").removeAttr('style');
		}
		if (!eMailVerification()) {
			verification = false;
			$("#e_mail").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#e_mail").removeAttr('style');
		}
		if (!verificateTextField($("#country").val())) {
			verification = false;
			$("#country").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#country").removeAttr('style');
		}
		if (!verificateTextField($("#city").val())) {
			verification = false;
			$("#city").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#city").removeAttr('style');
		}
		if (!verificateTextField($("#region").val())) {
			verification = false;
			$("#region").css('box-shadow', 'rgb(234, 0, 0) 0px 0px 4px');
		} else {
			$("#region").removeAttr('style');
		}
		return verification;
	}

	function submitData() {
		$.post("insert_data", {
			name : $("#name").val(),
			surname : $("#surname").val(),
			dateOfBirth : $("#date_of_birth").val(),
			phoneNumber : $("#phone_number").val(),
			eMail : $("#e_mail").val(),
			country : $("#country").val(),
			city : $("#city").val(),
			region : $("#region").val()
		}, function(data, status) {
			if (data == "true") {
				resetInput();
			} else {
				alert("Insert error");
			}
		});
	}
	function resetInput() {
		$("#name").val("");
		$("#surname").val("");
		$("#date_of_birth").val("");
		$("#phone_number").val("");
		$("#e_mail").val("");
		$("#country").val("");
		$("#city").val("");
		$("#region").val("");
	}

	function eMailVerification() {
		var regexp = /[A-z\d]{1,}@[A-z]{1,}\.[A-z]{1,}/;
		var result = regexp.test($("#e_mail").val());
		return result;
	}

	function verificateTextField(fieldValue) {
		var regexp = /^[A-zА-я -]{2,}$/;
		var result = regexp.test(fieldValue);
		return result;
	}

	function verificatePhoneNumber() {
		var regexp = /^\d{3,}$/;
		var result = regexp.test($("#phone_number").val());
		return result;
	}
	function setMaxDateToToday() {
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth() + 1;
		var yyyy = today.getFullYear();
		if (dd < 10) {
			dd = '0' + dd
		}
		if (mm < 10) {
			mm = '0' + mm
		}
		today = yyyy + '-' + mm + '-' + dd;
		$("#date_of_birth").attr({
			"min" : "1900-01-01",
			"max" : today
		});
	}
	function verificateBirthDate() {
		var selectedDate = new Date($("#date_of_birth").val());
		var today = new Date();
		var minDate = new Date("1900-01-01");
		var result = false;
		if(selectedDate <= today && selectedDate >= minDate) {
			result = true;
		}
		return result;
	}