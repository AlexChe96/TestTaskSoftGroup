package che.alex.SQL;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class SQLConnetionFactory {
	
	private static InitialContext initContext;
	private static DataSource dataSource;

    public static Connection getConnection() throws SQLException, NamingException {
    	initContext = new InitialContext();
    	dataSource = (DataSource) initContext.lookup("java:comp/env/jdbc/test_task");
    	return dataSource.getConnection();
    }
}