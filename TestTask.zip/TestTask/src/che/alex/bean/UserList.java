package che.alex.bean;

import java.util.ArrayList;
import che.alex.User;
import che.alex.DAO.UserController;


public class UserList {
	
	private ArrayList<User> userList = null;
	UserController userController;
	
	public UserList() {
		userController = new UserController();
	}

	public ArrayList<User> getUserList() {
		this.userList = (ArrayList<User>) userController.getAll();
		return this.userList;
	}

	public void setUserList(ArrayList<User> userList) {
		this.userList = userList;
	}
}