package che.alex.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import che.alex.User;

public class UserController extends AbstractController<User> {

	public static final String SELECT_ALL_USERS = "SELECT * FROM users";
	public static final String INSERT_USER = "INSERT INTO users (`name`, `surname`, `date_of_birth`,"
			+ " `phone_number`, `e-mail`, `country`, `city`, `region`)"
			+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
	
	@Override
	public List<User> getAll() {
		List<User> userList = new ArrayList<User>();
        PreparedStatement ps = getPrepareStatement(SELECT_ALL_USERS);
        Connection connection = null;;
        try {
        	connection = ps.getConnection();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) { 
                User user = new User();
                user.setId(rs.getInt("user_id"));
                user.setName(rs.getString("name"));
                user.setSurname(rs.getString("surname"));
                user.setDateOfBirth(rs.getString("date_of_birth"));
                user.seteMail(rs.getString("e-mail"));
                user.setPhoneNumber(rs.getString("phone_number"));
                user.setCountry(rs.getString("country"));
                user.setRegion(rs.getString("region"));
                user.setCity(rs.getString("city"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closePrepareStatement(ps);
            closeConnection(connection);
        }
        return userList;
	}

	@Override
	public boolean insert(Object... fieldsValues) {
		PreparedStatement ps = getPrepareStatement(INSERT_USER);
		Connection connection = null;
		boolean result = false;
		try {
			connection = ps.getConnection();
			for (int i = 0; i < fieldsValues.length; i++) {
				ps.setString(i+1, (String) fieldsValues[i]);
			}
			if( ps.executeUpdate() > 0) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
            closePrepareStatement(ps);
            closeConnection(connection);
		}
		return result;
	}
}
